'use strict';
var AWS = require('aws-sdk');
var pify = require('pify');
var Promise = require('pinkie-promise');
var ec2 = new AWS.EC2();
exports.handler = function (event, context) {
	var describeParams = {
		Filters: [
			{
				Name: 'tag:StopGroup',
				Values: [
					context.functionName
				]
			}
		]
	};
	pify(ec2.describeInstances.bind(ec2), Promise)(describeParams)
		.then(function (data) {
			var stopParams = {
				InstanceIds: []
			};
			data.Reservations.forEach(function (reservation) {
				reservation.Instances.forEach(function (instance) {
					if (instance.State.Code === 16) {
						stopParams.InstanceIds.push(instance.InstanceId);
					}
				});
			});
			if (stopParams.InstanceIds.length > 0) {
				return pify(ec2.stopInstances.bind(ec2), Promise)(stopParams);
			}
		})
		.then(context.succeed)
		.catch(context.fail);
};
